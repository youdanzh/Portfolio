
function closeForm()
{
	document.getElementById("myForm").style.display = "none";
}

function openForm()
{
	document.getElementById("myForm").style.display = "block";
}

function closeCreate()
{
	document.getElementById("create-popup").style.display = "none";
}

function openCreate()
{
	document.getElementById("create-popup").style.display = "block";
}

function closeAbout()
{
	document.getElementById("about-popup").style.display = "none";
}

function openAbout()
{
	document.getElementById("about-popup").style.display = "block";
}

function closePost()
{
	document.getElementById("post-popup").style.display = "none";
}

function openPost()
{
	document.getElementById("post-popup").style.display = "block";
}


function openTab(evt, tabName) {
	var i, tabcontent, tablinks;
	tabcontent = document.getElementsByClassName("tabcontent");
	for (i = 0; i < tabcontent.length; i++) {
		tabcontent[i].style.display = "none";
	}
	tablinks = document.getElementsByClassName("tablinks");
	for (i = 0; i < tablinks.length; i++) {
		tablinks[i].className = tablinks[i].className.replace(" active", "");
	}
	document.getElementById(tabName).style.display = "block";
	evt.currentTarget.className += " active";
}
