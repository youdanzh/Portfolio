package com.fitbook.fitbook;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;


public class LoginActivity extends AppCompatActivity implements View.OnClickListener {


    EditText mMobileEt; //user edit phone number
    EditText mPwdEt; //user edit password
    Button btLogin; //user login button
    TextView mRegisterTv; //display register

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initView();
        User admin=new User(); 
        admin.setUname("admin"); //Manager account username
        admin.setUpasswd("admin"); //Manager account password
        admin.setUserType(0);
        DBDao.getInstance(this).registerUser(admin);
    }

    private void initView() {
        mMobileEt = findViewById(R.id.mMobileEt);
        mPwdEt = findViewById(R.id.mPwdEt);
        btLogin = findViewById(R.id.btLogin);
        mRegisterTv = findViewById(R.id.mRegisterTv);
        btLogin.setOnClickListener(this);
        mRegisterTv.setOnClickListener(this);
    }


    private void login(String name, String pwd) {
        int id = DBDao.getInstance(this).userLogin(name, pwd);
        if (id != -1) {
            SPUtils.put(this, "id", id);
            User user = DBDao.getInstance(this).getUserInfoById(id);
            if (user.getUserType()==0){
                startActivity(new Intent(LoginActivity.this, Manager.class));
            }else if (user.getUserType()==1){
                startActivity(new Intent(LoginActivity.this, Employee.class));
            }else if (user.getUserType()==2){
                startActivity(new Intent(LoginActivity.this, MainActivity.class));
            }
            finish();
        } else {
            Toast.makeText(LoginActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
        }

    }




    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btLogin:
                String name = mMobileEt.getText().toString();
                String pwd = mPwdEt.getText().toString();
                if (TextUtils.isEmpty(name)) {
                    Toast.makeText(LoginActivity.this, "Username cannot be blank", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(pwd)) {
                    Toast.makeText(LoginActivity.this, "User password cannot be blank", Toast.LENGTH_SHORT).show();
                    return;
                }
                login(name, pwd);
                break;
            case R.id.mRegisterTv:
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
                break;
        }
    }
}
