package com.fitbook.fitbook;

import android.content.ContentValues;

public class User {



    int uid;
    String uname;
    String upasswd;
    String utel;
    String utext;
    String usex;
    String vipType;
    String vipDays;
    int userType;
    String salary;
    public static ContentValues getUserValues(User user){
        ContentValues cv = new ContentValues();
        cv.put("uname", user.getUname());
        cv.put("upasswd", user.getUpasswd());
        cv.put("utel", user.getUtel());
        cv.put("utext", user.getUtext());
        cv.put("usex", user.getUsex());
        cv.put("vipType", user.getVipType());
        cv.put("vipDays", user.getVipDays());
        cv.put("userType", user.getUserType());
        cv.put("salary", user.getSalary());
        return cv;
    }

    public User() {
    }

    public User(int uid, String uname, String upasswd, String utel, String utext, String usex ,String vipType,String vipDays,int userType,String salary) {
        this.uid = uid;
        this.uname = uname;
        this.upasswd = upasswd;
        this.utel = utel;
        this.utext = utext;
        this.usex = usex;
        this.vipType = vipType;
        this.vipDays = vipDays;
        this.userType = userType;
        this.salary = salary;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public int getUserType() {
        return userType;
    }

    public void setUserType(int userType) {
        this.userType = userType;
    }

    public String getVipType() {
        return vipType;
    }

    public void setVipType(String vipType) {
        this.vipType = vipType;
    }

    public String getVipDays() {
        return vipDays;
    }

    public void setVipDays(String vipDays) {
        this.vipDays = vipDays;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getUpasswd() {
        return upasswd;
    }

    public void setUpasswd(String upasswd) {
        this.upasswd = upasswd;
    }

    public String getUtel() {
        return utel;
    }

    public void setUtel(String utel) {
        this.utel = utel;
    }

    public String getUtext() {
        return utext;
    }

    public void setUtext(String utext) {
        this.utext = utext;
    }


    public String getUsex() {
        return usex;
    }

    public void setUsex(String usex) {
        this.usex = usex;
    }
}
