package com.fitbook.fitbook;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MyMemberShipActivity extends BaseActivity {
    private TextView tvType;
    private TextView tvDay;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mymembership);
        onSetTitle("My MemberShip");
        initView();
    }

    private void initView() {
        Button button10 = findViewById(R.id.button10);
        Button button11 = findViewById(R.id.button11);
        tvType = findViewById(R.id.tv_type);
        tvDay= findViewById(R.id.tv_day);
        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MyMemberShipActivity.this,ChangeMemberShipActivity.class));
            }
        });
        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               cancel();
            }
        });
    }

    private void cancel() {
        int id = (int) SPUtils.get(MyMemberShipActivity.this, "id", 0);
        final User user = DBDao.getInstance(MyMemberShipActivity.this).getUserInfoById(id);
        user.setVipType("");
        user.setVipDays("0");
        new AlertDialog.Builder(MyMemberShipActivity.this)
                .setTitle("Notice")
                .setMessage("Are you sure to delete your membership")
                .setPositiveButton("confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                        DBDao.getInstance(MyMemberShipActivity.this).updateUser(user);
                        onToast("Cancel Sussessful");
                        tvType.setText("");
                        tvDay.setText("0");
                    }
                }).setNegativeButton("cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).create().show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        int id = (int) SPUtils.get(this, "id", 0);
        User user = DBDao.getInstance(this).getUserInfoById(id);
        if (!TextUtils.isEmpty(user.getVipType())) {
            tvType.setText(user.getVipType());
            tvDay.setText(user.getVipDays());
        }
    }
}
