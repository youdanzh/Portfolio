package com.fitbook.fitbook;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;



public class RegisterActivity extends BaseActivity implements View.OnClickListener {
    private EditText etName;
    private EditText etPwd;
    private Button btLogin;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        onSetTitle("Sign up");
        init();
    }

    private void init() {
        etName = findViewById(R.id.et_write_name);
        etPwd = findViewById(R.id.et_write_pwd);
        btLogin = findViewById(R.id.btn_login);
        btLogin.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_login:
                String name=etName.getText().toString().trim();
                String pass=etPwd.getText().toString().trim();
                if (TextUtils.isEmpty(name)){
                    onToast("User name cannot be blank");
                    return;
                }
                if (TextUtils.isEmpty(pass)){
                    onToast("Password cannot be blank");
                    return;
                }
                User user=new User();
                user.setUname(name);
                user.setUpasswd(pass);
                user.setUserType(2);
                if (DBDao.getInstance(this).registerUser(user)){
                    Toast.makeText(RegisterActivity.this,"Register Successful",Toast.LENGTH_SHORT).show();
                    finish();
                }
                else
                {
                    Toast.makeText(RegisterActivity.this,"Register Failure",Toast.LENGTH_SHORT).show();
                }

                break;

        }
    }

}
