package com.fitbook.fitbook;

import android.content.ContentValues;

public class Paypal { //Payment class
    int id;

    String name;
    String cardNo;
    String time;
    String cvv;
    String address;
    String pwd;
    String uid;

    public Paypal(int id, String name, String cardNo, String time, String cvv, String address, String pwd, String uid) {
        this.id = id;
        this.name = name;
        this.cardNo = cardNo;
        this.time = time;
        this.cvv = cvv;
        this.address = address;
        this.pwd = pwd;
        this.uid = uid;
    }

    public Paypal(String name, String cardNo, String time, String cvv, String address, String pwd, String uid) {
        this.name = name;
        this.cardNo = cardNo;
        this.time = time;
        this.cvv = cvv;
        this.address = address;
        this.pwd = pwd;
        this.uid = uid;
    }

    public static ContentValues getValues(Paypal paypal) {
        ContentValues cv = new ContentValues();
        cv.put("name", paypal.getName());
        cv.put("cardNo", paypal.getCardNo());
        cv.put("time", paypal.getTime());
        cv.put("cvv", paypal.getCvv());
        cv.put("address", paypal.getAddress());
        cv.put("pwd", paypal.getPwd());
        cv.put("uid", paypal.getUid());
        return cv;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }
}
