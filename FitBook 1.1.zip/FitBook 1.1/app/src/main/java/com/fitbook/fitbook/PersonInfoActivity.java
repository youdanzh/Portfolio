package com.fitbook.fitbook;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.View;
import android.widget.DatePicker;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.Calendar;


public class PersonInfoActivity extends BaseActivity {

    private int select = 0;
    TextView tvName;
    TextView tvTel;
    RelativeLayout llPhone;
    String[] sex = new String[]{"Male", "Female"};
    private View llGender;
    private TextView tvGender;
    private TextView tvBirthday;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person_info);
        onSetTitle("");
        initView();

    }

    private void initView() {
        tvName =  findViewById(R.id.tv_name);
        tvGender =  findViewById(R.id.tv_gender);
        llPhone =  findViewById(R.id.rl_phone);
        tvBirthday =  findViewById(R.id.tv_birthday);
        tvTel =  findViewById(R.id.tv_phone);
        llGender =  findViewById(R.id.ll_gender);
        View llBirthday = findViewById(R.id.ll_birthday);
        llPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PersonInfoActivity.this, ChangePhoneActivity.class));
            }
        });
        llGender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(PersonInfoActivity.this)
                        .setTitle("Gender").setSingleChoiceItems(sex, 0, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        select = which;
                    }
                }).setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        tvGender.setText(sex[select]);
                        updateUser(sex[select]);
                        dialog.dismiss();
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();
            }
        });
        llBirthday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showTime();
            }


        });

    }
    private void showTime() {
        Calendar ca = Calendar.getInstance();
        int  mYear = ca.get(Calendar.YEAR);
        int  mMonth = ca.get(Calendar.MONTH);
        int  mDay = ca.get(Calendar.DAY_OF_MONTH);


        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                         String data =year+"-" +  (month+1) + "-" + dayOfMonth + " ";
                        tvBirthday.setText(data);
                        int id = (int) SPUtils.get(PersonInfoActivity.this, "id", 0);
                        User user = DBDao.getInstance(PersonInfoActivity.this).getUserInfoById(id);
                        user.setUtext(data);
                        DBDao.getInstance(PersonInfoActivity.this).updateUser(user);
                    }
                },
                mYear, mMonth, mDay);
        datePickerDialog.show();

    }
    private void updateUser(String sex) {
        int id = (int) SPUtils.get(this, "id", 0);
        User user = DBDao.getInstance(this).getUserInfoById(id);
        user.setUsex(sex);
        DBDao.getInstance(this).updateUser(user);
    }

    @Override
    protected void onResume() {
        super.onResume();
        int id = (int) SPUtils.get(this, "id", 0);
        User user = DBDao.getInstance(this).getUserInfoById(id);
        tvName.setText(user.getUname());
        if (!TextUtils.isEmpty(user.getUtel())){
            tvTel.setText(user.getUtel());
        }
        if (!TextUtils.isEmpty(user.getUtext())){
            tvBirthday.setText(user.getUtext());
        }

    }



}
