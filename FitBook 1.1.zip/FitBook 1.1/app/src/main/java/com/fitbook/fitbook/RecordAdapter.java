package com.fitbook.fitbook;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class RecordAdapter extends RecyclerView.Adapter<RecordAdapter.DataHolder>{
    private List<EmployeeRecord> userList;
    private Context context;

    public RecordAdapter(Context context, List<EmployeeRecord> data) {
        userList = data;
        this.context = context;
    }

    @Override
    public DataHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.item_record,parent,false);
        return new DataHolder(view);
    }

    @Override
    public void onBindViewHolder(DataHolder holder, final int position) {
        EmployeeRecord user = userList.get(position);
        holder.saveData(user);
    }
    @Override
    public int getItemCount() {
        return userList.size();
    }

    public class DataHolder extends RecyclerView.ViewHolder {
        private TextView tv_start,tv_end,tv_salary,tv_total;

        public DataHolder(View itemView) {
            super(itemView);
            tv_start= itemView.findViewById(R.id.tv_start);
            tv_end= itemView.findViewById(R.id.tv_end);
            tv_salary= itemView.findViewById(R.id.tv_salary);
            tv_total= itemView.findViewById(R.id.tv_total);
        }
        //save data and store in list
        public void saveData(EmployeeRecord x){
            tv_start.setText(x.getStartTime()+"");
            tv_end.setText(x.getEndTime()+"");
            tv_salary.setText(x.getSalary()+"$/h");
            tv_total.setText(x.getTotal()+"$");
        }

    }
}
