package com.fitbook.fitbook;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

//Class for manager to access employee details
public class AddEmployeeActivity extends BaseActivity implements View.OnClickListener {
    private EditText etName; //usernnae
    private EditText etPwd; //password
    private Button btLogin; //login buttonn
    private EditText etSalary; //edit employee salary


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_employee);
        onSetTitle("Add Employee");
        init();
    }

    private void init() { //init constructor
        etName = findViewById(R.id.et_write_name);
        etPwd = findViewById(R.id.et_write_pwd);
        etSalary = findViewById(R.id.et_salary);
        btLogin = findViewById(R.id.btn_login);
        btLogin.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_login:
                String name=etName.getText().toString().trim();
                String pass=etPwd.getText().toString().trim();
                String salary=etSalary.getText().toString().trim();
                if (TextUtils.isEmpty(name)){
                    onToast("User name cannot be blank"); //username cannot be blank
                    return;
                }
                if (TextUtils.isEmpty(pass)){
                    onToast("Password cannnot be blank");  //password cannot be blank
                    return;
                }
                if (TextUtils.isEmpty(salary)){
                    onToast("Salary cannot be blank");  //salary cannot be blank
                    return;
                }
                User user=new User(); //user object
                user.setUname(name);
                user.setUpasswd(pass);
                user.setSalary(salary);
                user.setUserType(1);
                if (DBDao.getInstance(this).registerUser(user)){ //registering new employee
                    Toast.makeText(AddEmployeeActivity.this,"Add Successful",Toast.LENGTH_SHORT).show();
                    finish();
                }
                else
                {
                    Toast.makeText(AddEmployeeActivity.this,"Add Failure",Toast.LENGTH_SHORT).show();
                }

                break;

        }
    }

}
