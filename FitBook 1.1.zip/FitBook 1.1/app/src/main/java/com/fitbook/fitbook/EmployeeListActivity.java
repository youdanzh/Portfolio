package com.fitbook.fitbook;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.InputType;
import android.text.TextUtils;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;


public class EmployeeListActivity extends BaseActivity  {


    private RecyclerView recyclerview;
    private List<User> list = new ArrayList<>();
    private EmployeeAdapter mAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employeelist);
        onSetTitle("Employee List");
    }

    @Override
    protected void onResume() {
        super.onResume();
        init();
    }

    private void init() {

        recyclerview =  findViewById(R.id.recyclerview);
        recyclerview.setLayoutManager(new LinearLayoutManager(this));
        recyclerview.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        list.clear();
        List<User> datas = DBDao.getInstance(this).loadEmployee();
        list.addAll(datas);
        mAdapter = new EmployeeAdapter(this,list);
        recyclerview.setAdapter(mAdapter);
        recyclerview.setItemAnimator(new DefaultItemAnimator());
        mAdapter.setOnItemClickListener(new EmployeeAdapter.ItemClickListener(){

            @Override
            public void setOnItemClickListener(final int position) {
                final EditText et = new EditText(EmployeeListActivity.this);
                et.setInputType(InputType.TYPE_CLASS_NUMBER);
                new AlertDialog.Builder(EmployeeListActivity.this)
                        .setTitle("Comments")
                        .setMessage("Update Salary")
                        .setView(et)
                        .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                User user = list.get(position);
                                User newUser = DBDao.getInstance(EmployeeListActivity.this).getUserInfoById(user.getUid());
                                String num = et.getText().toString();
                                if (TextUtils.isEmpty(num)){
                                    onToast("Enter Salary");
                                    return;
                                }
                                newUser.setSalary(num);
                                user.setSalary(num);
                                DBDao.getInstance(EmployeeListActivity.this).updateUser(newUser);
                                dialogInterface.dismiss();
                                mAdapter.notifyItemChanged(position);
                            }
                        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                }).create().show();
            }
        });
        mAdapter.setOnItemLongClickListener(new EmployeeAdapter.ItemLongClickListener() {
            @Override
            public void setOnItemClickListener(final int position) {
                new AlertDialog.Builder(EmployeeListActivity.this)
                        .setTitle("Comments")
                        .setMessage("Confirm Delete?")
                        .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                User user = list.get(position);
                                list.remove(position);
                                mAdapter.notifyDataSetChanged();
                                DBDao.getInstance(EmployeeListActivity.this).delUser(user.getUid()+"");
                            }
                        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                }).create().show();
            }
        });
    }




}
