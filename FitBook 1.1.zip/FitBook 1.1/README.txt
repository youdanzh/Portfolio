CIS 454 FitBook

Team Contributors:
Andy Chen
Youdan Zhang
Carlos Leal
Owen Williams

Getting Started
1.Download Android Studios https://developer.android.com/studio/
2.Once downloaded open project by clicking “Open an existing Android Studio project” and 3.select the FitBook folder. Then click “Open” to access all files.
4.To access codes, click on app → src → main → java
5.To compile and run, click on “Run” on the top panel. Then click “Run app”.
6.Select a Android virtual machine if you have not yet selected by clicking “Create New Virtual Device”.
7.Click to select the Pixel phone API/Nexus Phone. 
8.Once selected, click to download the latest software (Pie). 
9.Username: admin Password:admin is for the Manager to login
10. Manager can add employees Name, password and payrate
11.Click on specific employee on employee list can update employee salary
12.Click on specific employee on employee list for 1.5 sec can Delete employee.
13.login employee view by the name and password registered by the Manager.
14.Clock in for working Clock out for finish. Will calculate payment after clock out
15.If working less than 1 hr, no payment.
16.Sign up button on the login page is only for member register.
17.Sign in the member by the account signed up.
18. Profile is for change phone number and birthday and gender
19. Change membership is for change membership type and cancel membership
20.Update payment is for bank card store
21.Use the SQLite database for data


