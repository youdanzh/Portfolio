from pymongo import MongoClient
from conf import config
from models import lagou
from pprint import pprint
from mongoengine import *
import json
import sys
import datetime
import matplotlib.pyplot as plt
import numpy as np
import regex as re


client = MongoClient("mongodb://localhost:27017/")# connection to MongoDB
db = client["work_object"]

class bundle:
    def __init__(self,title,num):
        self.n = title
        self.num = num
############# by cities
cities = db.lagou.distinct("city")
cTrans = ['All','Beijing','Shanghai','Hangzhou','Guangzhou','Wuhan','Shenzhen','Chengdu'
          ,'Jiangsu']
countC = []
for city in cities:
    n = db.lagou.count_documents({"city": city})
    countC.append(n)
    string = city + ": " + str(n)
    print(string)
#plt.rcParams['font.sans-serif']=['SimHei']
#plt.rcParams['axes.unicode_minus'] = False
y_pos = np.arange(len(cTrans))
plt.bar(y_pos, countC, align='center', alpha=0.5)
plt.xticks(y_pos,cTrans,rotation = 30)
### under is line graph
plt.plot(cTrans,countC)
plt.xlabel('cities')
plt.ylabel('number of jobs posted')
plt.title('Jobs by cities')
plt.savefig('jobsByCities.png')
plt.show()
#########jobs by position

positions = ['COO','互联网','大数据','工程师','游戏','MySQL','Java','Python','Oracle','用户运营','C++','Node.js','PHP','图像','c']
postTran = ['COO','Internet','Data','Engineer','Game','MySQL','Java','Python','Oracle','User Management','C++','Node.js','PHP','Visual','c']
countP = []
for pos in positions:
    p = db.lagou.count_documents({"positionname" : { "$regex" : pos,"$options" : 'i'}})
    ##p = db.lagou.count_documents({"positionname" : pos})
    countP.append(p)
    st = pos+": " + str(p)
    print(st)
y_pos = np.arange(len(postTran))
plt.bar(y_pos, countP, align='center', alpha=0.5)
plt.xticks(y_pos,postTran,rotation = 75)
### under is line graph
plt.plot(postTran,countP)
plt.xlabel('position')
plt.ylabel('number of jobs posted')
plt.title('Jobs by positoin')
plt.savefig('jobsByPositions.png')
plt.show()
             
             
             
if __name__ == "__fetchAndGraph__":
    print()
